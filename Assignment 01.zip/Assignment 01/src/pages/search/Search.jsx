/** @format */
import Footer from "../home/Component/footer/Footer";
import HeaderSection from "../home/Component/header/HeaderSection";
import SearchSection from "./Component/SearchSection";

const Search = () => {
  return (
    <>
      <HeaderSection />
      <SearchSection />
      <Footer />
    </>
  );
};

export default Search;
