/** @format */

const SearchPopup = () => {
  return (
    <div className='w-1/4'>
      <div className='bg-yellow-500  pt-5 pb-5'>
        <h1 className='ml-4 text-3xl font-bold text-gray-500'>Search</h1>
        <form>
          <div className='ml-4 mt-3'>
            <label htmlFor='text'>Destination</label>
            <input className='p-1' type='text'></input>
          </div>
          <div className='ml-4 mt-3'>
            {" "}
            <label htmlFor='text'>Check-in Date</label>
            <input className='p-1 pl-5 pr-16' type='date'></input>
          </div>
          <div>
            <label className='block ml-4 mt-3' htmlFor='text'>
              Options
            </label>
            <div className='ml-7 mt-3 flex justify-between'>
              <label className=' font-light'>
                Min price <span className='text-sm'>per night</span>
              </label>
              <input
                className=' p-1 mr-3 border border-slate-400 '
                type='text'
                size='1'></input>
            </div>
            <div className='ml-7 mt-3 flex justify-between'>
              <label className=' font-light' htmlFor='text'>
                Max price <span className='text-sm'>per night</span>
              </label>
              <input
                className=' mr-3 p-1 border border-slate-400 '
                type='text'
                size='1'></input>
            </div>
            <div className='ml-7 mt-3 flex justify-between'>
              <label className=' font-light'>Adult</label>
              <input
                className=' mr-3 p-1 border border-slate-400 '
                type='text'
                placeholder='1'
                size='1'></input>
            </div>
            <div className='ml-7 mt-3 flex justify-between'>
              <label className=' font-light'>Children</label>
              <input
                className=' mr-3 p-1 border border-slate-400 '
                type='text'
                placeholder='0'
                size='1'></input>
            </div>
            <div className='ml-7 mt-3 flex justify-between'>
              <label className=' font-light'>Room</label>
              <input
                className=' mr-3 p-1 border border-slate-400 '
                type='text'
                placeholder='1'
                size='1'></input>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SearchPopup;
