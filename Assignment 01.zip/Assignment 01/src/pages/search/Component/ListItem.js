/** @format */

const Listitem = (props) => {
  function onActiveDetail(e) {
    e.preventDefault();
    window.location.assign("/detail");
  }

  return (
    <li>
      <div className='flex gap-3 mb-5 p-2  border border-collapse rounded-lg justify-between'>
        <img className='w-64 h-64' src={props.image} alt='hinh loi'></img>
        <div className='flex-col w-80 text-sm'>
          <h1 className='text-2xl font-bold text-sky-800 mb-2'>{props.name}</h1>
          <p className='mb-3'>{props.distance} from center</p>
          <span className='p-1 text-white bg-green-600 rounded-md'>
            {props.tag}
          </span>
          <p className='mt-3 font-bold'>{props.description}</p>
          <p className='mt-3 '>{props.type}</p>
          {props.free_cancel && (
            <div className='mt-3 text-green-600'>
              <p className='font-bold mb-3'>Free cancellation</p>
              <p>You can cancel later, so lock in this great price today</p>
            </div>
          )}
        </div>
        <div className='flex flex-col justify-between w-44'>
          <div className='flex items-center justify-between'>
            <span className='font-bold text-md'>{props.rate_text}</span>
            <span className='p-1 bg-blue-700 text-white font-semibold'>
              {props.rate}
            </span>
          </div>
          <div>
            {" "}
            <div className='flex flex-col items-end  gap-2'>
              <span className='text-3xl  font-bold '>${props.price}</span>
              <span className='text-sm text-gray-500'>
                Includes taxes and fees
              </span>
              <button
                className='p-2 bg-blue-700 text-white w-full'
                onClick={onActiveDetail}>
                See availability
              </button>
            </div>
          </div>
        </div>
      </div>
    </li>
  );
};

export default Listitem;
