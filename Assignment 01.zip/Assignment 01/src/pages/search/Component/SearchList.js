/** @format */
import ListItem from "./ListItem";

const SearchList = (props) => {
  return (
    <div>
      <ul>
        {props.items.map((item) => {
          return (
            <ListItem
              key={item.name}
              name={item.name}
              distance={item.distance}
              tag={item.tag}
              type={item.type}
              description={item.description}
              free_cancel={item.free_cancel}
              price={item.price}
              rate={item.rate}
              rate_text={item.rate_text}
              image={item.image_url}
            />
          );
        })}
      </ul>
    </div>
  );
};

export default SearchList;
