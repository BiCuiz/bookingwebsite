/** @format */
import SearchPopup from "./SearchPopup";
import SearchList from "./SearchList";
import dataSearch from "../../../data/search.json";

const SearchSection = () => {
  return (
    <section className='px-56 mt-16 mb-12 flex gap-5'>
      <SearchPopup />
      <SearchList items={dataSearch} />
    </section>
  );
};

export default SearchSection;
