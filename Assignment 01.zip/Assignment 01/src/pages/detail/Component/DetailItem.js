/** @format */
import { FaLocationDot } from "react-icons/fa6";

const DetailItem = (props) => {
  return (
    <>
      <div className='flex items-start justify-between'>
        <div>
          <h1 className='text-3xl font-bold mb-3'>{props.name}</h1>
          <div className='flex items-center gap-2 mb-3'>
            <FaLocationDot />
            <p className='text-sm'>{props.address} </p>
          </div>
          <p className='text-lg font-semibold text-blue-700'>
            {props.distance}
          </p>
          <p className='text-lg font-semibold text-green-600'>{props.price}</p>
        </div>
        <button className='p-2 bg-blue-700 text-white rounded-md'>
          Reserve or Book Now!
        </button>
      </div>
      <div className='my-5 grid grid-rows-2 grid-flow-col gap-3'>
        {props.photos.map((photo, i) => {
          return (
            <div className='w-full overflow-hidden shadow-md' key={i}>
              <img src={photo} alt='hinh loi' />
            </div>
          );
        })}
      </div>
      <div className='flex justify-between gap-5 mt-5'>
        <div className='w-3/4'>
          <h1 className='my-4 text-3xl font-bold'>{props.title}</h1>
          <p>{props.description} </p>
        </div>
        <div className='w-1/4 h-80 p-4 bg-blue-200'>
          <h2 className='text-xl font-semibold text-slate-600 my-3'>
            Perfect for a 9-night stay!
          </h2>
          <p>
            Located in the real heart of Krakow, this property has excellent
            location score of 9.8!
          </p>
          <div className='flex items-center my-6 text-2xl '>
            <span className='font-bold'>${props.nine}</span>
            <span className='font-light'>(9 nights)</span>
          </div>
          <button className='p-2 bg-blue-700 text-white rounded-md w-full'>
            Reserve or Book Now!
          </button>
        </div>
      </div>
    </>
  );
};

export default DetailItem;
