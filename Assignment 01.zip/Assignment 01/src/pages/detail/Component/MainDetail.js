/** @format */

import DetailItem from "./DetailItem";

const MainDetail = (props) => {
  return (
    <div className='px-56 my-10'>
      <DetailItem
        key={props.items.name}
        name={props.items.name}
        address={props.items.address}
        distance={props.items.distance}
        price={props.items.price}
        photos={props.items.photos}
        title={props.items.title}
        description={props.items.description}
        nine={props.items.nine_night_price}
      />
    </div>
  );
};

export default MainDetail;
