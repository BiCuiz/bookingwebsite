/** @format */
import Navbar from "../home/Component/header/Narbar";
import itemNav from "../../data/navBar.json";
import Footer from "../home/Component/footer/Footer";
import itemDetail from "../../data/detail.json";
import MainDetail from "./Component/MainDetail";

const Detail = () => {
  return (
    <>
      <header className='header'>
        <Navbar items={itemNav} />
      </header>
      <MainDetail items={itemDetail} />
      <Footer />
    </>
  );
};

export default Detail;
