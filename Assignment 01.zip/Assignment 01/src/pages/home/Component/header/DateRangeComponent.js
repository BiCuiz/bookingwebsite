/** @format */

import { useState, useEffect, useRef } from "react";
import { DateRange } from "react-date-range";

import { format, addDays } from "date-fns";

import "react-date-range/dist/styles.css"; // main style file
import "react-date-range/dist/theme/default.css";

const DateRangeComponent = () => {
  const [dateRange, setDateRange] = useState([
    {
      startDate: new Date(),
      endDate: addDays(new Date(), 7),
      key: "selection",
    },
  ]);
  const [isOpen, setIsOpen] = useState(false);
  const refRange = useRef(null);

  const handleClickOutside = (event) => {
    if (refRange.current && !refRange.current.contains(event.target)) {
      setIsOpen(false);
    }
  };
  const handleKeyDownESC = (event) => {
    if (event.key === "Escape") {
      setIsOpen(false);
    }
  };
  //su dung useEffect de load hanh dong khi duoc tai
  useEffect(() => {
    //them su kien click tren trang va su kien nhan ESC
    document.addEventListener("click", handleClickOutside, true);
    document.addEventListener("keydown", handleKeyDownESC, true);
  }, []);

  const handleOpen = () => {
    setIsOpen(true);
  };

  return (
    <div className='text-black'>
      <input
        type='text'
        value={`${format(dateRange[0].startDate, "dd/MM/yyyy")} - ${format(
          dateRange[0].endDate,
          "dd/MM/yyyy"
        )} `}
        onClick={handleOpen}
        readOnly></input>
      <div ref={refRange}>
        {isOpen && (
          <DateRange
            onChange={(item) => setDateRange([item.selection])}
            editableDateInputs={true}
            moveRangeOnFirstSelection={false}
            months={1}
            ranges={dateRange}
            direction='horizontal'
            className='bg-white absolute -left-5 top-10 z-10 border-2 rounded-lg border-orange-100 p-1'
          />
        )}
      </div>
    </div>
  );
};

export default DateRangeComponent;
