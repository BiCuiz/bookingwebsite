/** @format */

import NavbarItem from "./NavbarItem";

const Navbar = (props) => {
  function logoClick(e) {
    e.preventDefault();
    window.location.replace("/");
  }
  return (
    <>
      <div className='flex items-center justify-between pt-5'>
        <div className='text-2xl font-bold'>
          <button onClick={logoClick}>Booking Website</button>
        </div>
        <div>
          <button className='bg-white text-black m-2 px-2 py-2 rounded-sm'>
            Register
          </button>
          <button className='bg-white text-black m-2 px-2 py-2 rounded-sm'>
            Login
          </button>
        </div>
      </div>
      <nav>
        <ul className='flex items-center gap-5  '>
          {props.items.map((item) => (
            <NavbarItem
              key={item.type}
              icon={item.icon}
              type={item.type}
              active={item.active}
            />
          ))}
        </ul>
      </nav>
    </>
  );
};

export default Navbar;
