/** @format */

import Header from "./Header";
import Navbar from "./Narbar";
import itemNav from "../../../../data/navBar.json";

const HeaderSection = (props) => {
  return (
    <header className='px-56 bg-blue-900 text-white relative'>
      <Navbar items={itemNav} />
      <Header />
    </header>
  );
};

export default HeaderSection;
