/** @format */

const NavbarItem = (props) => {
  function activeChangeHandler(e) {
    e.preventDefault();
  }
  return (
    <li
      //
      className={`flex items-center gap-2 text-md p-1 border border-blue-900  ${
        props.active ? "border border-white rounded-lg" : ""
      }  hover:border hover:border-white hover:rounded-lg`}
      onClick={activeChangeHandler}>
      <button className={`fa ${props.icon}`}></button>
      <button>{props.type}</button>
    </li>
  );
};

export default NavbarItem;
