/** @format */
import { FaBed } from "react-icons/fa";
import { BiCalendar } from "react-icons/bi";
import { FaPerson } from "react-icons/fa6";
import DateRangeComponent from "./DateRangeComponent";

const Header = () => {
  //chuyển hướng trang
  function btnSearch() {
    window.location.assign(/search/);
  }

  return (
    <>
      <div className='flex flex-col gap-3 mt-10 '>
        <h1 className='text-3xl font-bold '>
          A lifetime of discounts? It's Genius
        </h1>
        <p>
          Get rewarded for your travel - unlock instant savings of 10% or more
          with a free account
        </p>
        <div className='mt-6'>
          <button className='px-6 py-4 bg-blue-500 shadow hover:shadow-lg '>
            Sign in/Register
          </button>
        </div>
      </div>
      <div className='mt-10 flex items-center justify-center gap-16 p-3 bg-white border-4 border-yellow-300 relative top-10 text-gray-300'>
        <div className='flex items-center gap-2 '>
          <FaBed />
          <input
            className='text-black'
            type='text'
            placeholder='Where are going?'></input>
        </div>
        <div className='flex items-center gap-2 relative '>
          <BiCalendar />
          <DateRangeComponent />
        </div>
        <div>
          <ul className='flex items-center gap-2 '>
            <li>
              <FaPerson />
            </li>
            <li className='flex'>
              <input className='w-5' type='text' placeholder='1'></input>
              <p>adult</p>
            </li>
            <li className='flex'>
              <input className='w-5' type='text' placeholder='0 '></input>
              <p>children</p>
            </li>
            <li className='flex'>
              <input className='w-5' type='text' placeholder='1'></input>
              <p>room</p>
            </li>
          </ul>
        </div>
        <div>
          <button
            className='px-3 py-2 bg-blue-500 shadow hover:shadow-lg '
            onClick={btnSearch}>
            Search
          </button>
        </div>
      </div>
    </>
  );
};

export default Header;
