/** @format */
import FooterItem from "./FooterItem";
import footerData from "../../../../data/footer.json";
import Form from "./Form";

const Footer = () => {
  return (
    <>
      <Form />
      <FooterItem items={footerData} />
    </>
  );
};

export default Footer;
