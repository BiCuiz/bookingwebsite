/** @format */

const Form = () => {
  return (
    <div className='mt-16 mb-10 p-10 px-56 bg-blue-900'>
      <h1 className='text-5xl font-bold text-white text-center p-2'>
        Save time, save money
      </h1>
      <p className='text-xl text-white text-center p-2'>
        Sign up and we'll send the best deals to you
      </p>
      <div className='text-center mt-5'>
        <input
          className='p-4 pr-20 pl-5 mr-10 rounded-lg'
          type='text'
          placeholder='Your Email'></input>
        <button
          className='p-4 bg-blue-500 text-white shadow hover:shadow-lg'
          type='submit'
          name='subscribe'>
          Subscribe
        </button>
      </div>
    </div>
  );
};
export default Form;
