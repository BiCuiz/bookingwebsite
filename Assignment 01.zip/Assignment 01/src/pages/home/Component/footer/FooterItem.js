/** @format */

const FooterItem = (props) => {
  return (
    <footer className='px-56 flex justify-center gap-20 mb-7'>
      {props.items.map((item) => {
        return (
          <ul key={item.col_number}>
            {item.col_values.map((value) => (
              <li className='text-cyan-800 font-sans  font-light' key={value}>
                {value}
              </li>
            ))}
          </ul>
        );
      })}
    </footer>
  );
};

export default FooterItem;
