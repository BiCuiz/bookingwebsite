/** @format */
import HotelItem from "./HotelItem";

const Hotel = (props) => {
  return (
    <section className='mt-16 mb-10 px-56'>
      <h1 className='text-2xl font-bold mb-10'>Hotel guests love</h1>
      <div className='flex gap-5'>
        {props.hotels.map((hotel) => {
          return (
            <HotelItem
              key={hotel.name}
              name={hotel.name}
              city={hotel.city}
              price={hotel.price}
              rate={hotel.rate}
              type={hotel.type}
              image={hotel.image_url}
            />
          );
        })}
      </div>
    </section>
  );
};

export default Hotel;
