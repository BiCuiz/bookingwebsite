/** @format */

import City from "./City";
import cityData from "../../../../data/city.json";
import typeHotelData from "../../../../data/type.json";
import hotelData from "../../../../data/hotel_list.json";
import Hotel from "./Hotel";
import TypeHotel from "./TypeHotel";

const Main = () => {
  return (
    <section className='z-0'>
      <City cities={cityData} />
      <TypeHotel typeHotels={typeHotelData} />
      <Hotel hotels={hotelData} />
    </section>
  );
};

export default Main;
