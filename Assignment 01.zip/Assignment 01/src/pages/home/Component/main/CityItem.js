/** @format */

const CityItem = (props) => {
  return (
    <div className='w-80 h-80 relative overflow-hidden rounded-2xl '>
      <img
        className='shadow hover:shadow-lg  '
        src={props.image}
        alt='hinhloi'
      />
      <div className='absolute left-5 bottom-4 text-white font-bold'>
        <p className='text-3xl'>{props.name}</p>
        <p className=' text-xl'>{props.subText}</p>
      </div>
    </div>
  );
};

export default CityItem;
