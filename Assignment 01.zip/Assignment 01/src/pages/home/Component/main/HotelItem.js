/** @format */

const HotelItem = (props) => {
  return (
    <div>
      <img className='w-64 h-64 mb-3' src={props.image} alt='hinh loi'></img>
      <a
        className='font-bold underline underline-offset-2 text-sky-800'
        href='/'>
        {props.name}
      </a>
      <p className='mt-2 text-slate-400'>{props.city}</p>
      <p className='font-bold mt-2'>
        Starting from <span>${props.price}</span>
      </p>

      <p className='mt-3 text-sm'>
        <span className='p-1 bg-blue-900 text-white font-bold'>
          {props.rate}
        </span>{" "}
        {props.type}
      </p>
    </div>
  );
};

export default HotelItem;
