/** @format */

const TypeHotelItem = (props) => {
  return (
    <div>
      <img
        className='w-full h-4/6 rounded-se-2xl rounded-ss-2xl shadow hover:shadow-md'
        src={props.image}
        alt='hinh loi'></img>
      <div className='mt-5 ml-3'>
        <p className='text-xl font-bold'>{props.name}</p>
        <p className='text-slate-400'>{props.count} hotels</p>
      </div>
    </div>
  );
};

export default TypeHotelItem;
