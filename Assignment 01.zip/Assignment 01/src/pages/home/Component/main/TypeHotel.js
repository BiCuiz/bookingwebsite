/** @format */
import TypeHotelItem from "./TypeHotelItem";

const TypeHotel = (props) => {
  return (
    <section className='mt-16 mb-10 px-56'>
      <h1 className='text-2xl font-bold mb-10'>Browse by property type</h1>
      <div className='flex gap-5'>
        {props.typeHotels.map((type) => {
          return (
            <TypeHotelItem
              key={type.name}
              image={type.image}
              name={type.name}
              count={type.count}
            />
          );
        })}
      </div>
    </section>
  );
};

export default TypeHotel;
