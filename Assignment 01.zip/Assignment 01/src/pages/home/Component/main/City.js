/** @format */
import CityItem from "./CityItem";

const City = (props) => {
  return (
    <section className='mt-20 mb-10 flex px-56 gap-6 flex-wrap clear-left'>
      {props.cities.map((city) => {
        return (
          <CityItem
            key={city.name}
            image={city.image}
            name={city.name}
            subText={city.subText}
          />
        );
      })}
    </section>
  );
};

export default City;
