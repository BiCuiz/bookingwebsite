/** @format */
import Main from "./Component/main/Main";
import Footer from "./Component/footer/Footer";
import HeaderSection from "./Component/header/HeaderSection";

const Home = () => {
  return (
    <>
      <HeaderSection />
      <Main />
      <Footer />
    </>
  );
};

export default Home;
